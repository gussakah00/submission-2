import L from "leaflet";
import { fetchStoriesWithToken } from "../../data/api.js";
import { authService } from "../../utils/auth.js";

// Fix Leaflet default icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
});

const defaultIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

const HomePage = {
  async render() {
    // Cek apakah user sudah login
    if (!authService.isLoggedIn()) {
      return `
        <section class="home-page" aria-labelledby="home-title">
          <h1 id="home-title" tabindex="0">Akses Ditolak</h1>
          <div style="text-align: center; padding: 40px;">
            <p>Anda harus login untuk mengakses halaman ini.</p>
            <a href="#/login" class="link">Masuk</a> atau 
            <a href="#/register" class="link">Daftar akun baru</a>
          </div>
        </section>
      `;
    }

    return `
      <section class="home-page" aria-labelledby="home-title">
        <h1 id="home-title" tabindex="0">Cerita di Sekitarmu</h1>
        <div id="map-container">
          <div id="map" style="height: 400px; margin-bottom: 24px; border-radius: 8px; border: 1px solid #ddd;" 
               aria-label="Peta interaktif menampilkan lokasi cerita"></div>
        </div>
        <div id="story-list" class="story-list">
          <p id="loading-message">Memuat cerita...</p>
        </div>
      </section>
    `;
  },

  async afterRender() {
    // Jika tidak login, tidak perlu lanjut
    if (!authService.isLoggedIn()) {
      return;
    }

    const container = document.querySelector("#story-list");
    const loadingMessage = document.querySelector("#loading-message");

    try {
      // Initialize map dengan error handling
      await this._initializeMap();

      // Load stories
      await this._loadStories();
    } catch (error) {
      console.error("Error in afterRender:", error);
      if (loadingMessage) loadingMessage.remove();
      container.innerHTML = `
        <div style="text-align: center; padding: 40px; color: #666;">
          <p>Terjadi kesalahan saat memuat halaman.</p>
          <button id="retry-loading" style="margin-top: 15px; padding: 10px 20px; background: #1976d2; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Coba Lagi
          </button>
        </div>
      `;

      // Add retry functionality
      const retryButton = document.getElementById("retry-loading");
      if (retryButton) {
        retryButton.addEventListener("click", () => {
          this.afterRender();
        });
      }
    }
  },

  async _initializeMap() {
    const mapContainer = document.querySelector("#map");
    if (!mapContainer) {
      throw new Error("Map container not found");
    }

    try {
      // Clear any existing map
      if (this._map) {
        this._map.remove();
      }

      // Initialize map dengan view Indonesia
      this._map = L.map("map").setView([-2.5, 118.0], 5);

      // Add tile layer dengan error handling
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 18,
        minZoom: 3,
      }).addTo(this._map);

      // Set default icon
      L.Marker.prototype.options.icon = defaultIcon;

      // Handle map errors
      this._map.on("tileerror", (error) => {
        console.error("Map tile error:", error);
      });

      return this._map;
    } catch (error) {
      console.error("Error initializing map:", error);

      // Show user-friendly error message
      const mapContainer = document.querySelector("#map-container");
      if (mapContainer) {
        mapContainer.innerHTML = `
          <div style="text-align: center; padding: 40px; color: #666; background: #f5f5f5; border-radius: 8px;">
            <p style="margin-bottom: 15px;">Tidak dapat memuat peta</p>
            <p style="margin-bottom: 20px; font-size: 14px;">Pastikan koneksi internet Anda stabil dan coba refresh halaman.</p>
            <button onclick="window.location.reload()" style="padding: 10px 20px; background: #1976d2; color: white; border: none; border-radius: 4px; cursor: pointer;">
              Refresh Halaman
            </button>
          </div>
        `;
      }
      throw error;
    }
  },

  async _loadStories() {
    const container = document.querySelector("#story-list");
    const loadingMessage = document.querySelector("#loading-message");

    try {
      const stories = await fetchStoriesWithToken();

      if (loadingMessage) loadingMessage.remove();

      if (!stories || stories.length === 0) {
        container.innerHTML = `
          <div style="text-align: center; padding: 40px;">
            <p>Belum ada cerita yang tersedia.</p>
            <p>Jadilah yang pertama untuk <a href="#/add" class="link">berbagi cerita</a>!</p>
          </div>
        `;
        return;
      }

      const markers = [];
      const storiesWithCoordinates = [];

      const storyItems = stories
        .map((story, index) => {
          let displayTitle = "Cerita Tanpa Judul";
          let displayDescription = story.description;

          // Extract title from description if formatted with **title**\n
          if (
            story.description &&
            story.description.startsWith("**") &&
            story.description.includes("**\n")
          ) {
            const parts = story.description.split("**\n");
            if (parts.length >= 2) {
              displayTitle = parts[0].replace("**", "").trim();
              displayDescription = parts.slice(1).join("").trim();
            }
          }

          // Use story.name if available and title is still default
          if (displayTitle === "Cerita Tanpa Judul" && story.name) {
            displayTitle = story.name;
          }

          const displayName = displayTitle;

          // Check if story has valid coordinates
          const hasValidCoordinates =
            story.lat &&
            story.lon &&
            !isNaN(parseFloat(story.lat)) &&
            !isNaN(parseFloat(story.lon)) &&
            parseFloat(story.lat) !== 0 &&
            parseFloat(story.lon) !== 0;

          // Add marker to map if coordinates are valid
          if (hasValidCoordinates && this._map) {
            try {
              const marker = L.marker([
                parseFloat(story.lat),
                parseFloat(story.lon),
              ]).addTo(this._map).bindPopup(`
                  <div style="max-width: 200px;">
                    <strong>${displayName}</strong><br>
                    <img src="${
                      story.photoUrl
                    }" alt="${displayName}" style="width:100%;height:auto;margin:5px 0;border-radius:4px;">
                    <p style="margin:8px 0;">${displayDescription.substring(
                      0,
                      100
                    )}${displayDescription.length > 100 ? "..." : ""}</p>
                    <small style="color:#666;">Lokasi: ${story.lat}, ${
                story.lon
              }</small>
                  </div>
                `);

              markers.push(marker);
              storiesWithCoordinates.push(story);
            } catch (markerError) {
              console.error(
                `Error adding marker for story ${index}:`,
                markerError
              );
            }
          }

          // Format date if available
          let dateInfo = "";
          if (story.createdAt) {
            try {
              const date = new Date(story.createdAt);
              dateInfo = `<small>Diposting: ${date.toLocaleDateString(
                "id-ID"
              )}</small>`;
            } catch (e) {
              console.error("Error formatting date:", e);
            }
          }

          return `
            <article class="story-card" data-index="${index}" tabindex="0" 
                     data-has-coordinates="${hasValidCoordinates}"
                     aria-label="Cerita: ${displayName}">
              <img src="${story.photoUrl}" 
                   alt="Foto ilustrasi cerita ${displayName}" 
                   class="story-photo" 
                   loading="lazy"
                   onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkdhbWJhciB0aWRhayB0ZXJzZWRpYTwvdGV4dD48L3N2Zz4='">
              <div class="story-content">
                <h3>${displayName}</h3>
                <p>${displayDescription}</p>
                <div class="story-meta">
                  <small>Lokasi: ${
                    hasValidCoordinates
                      ? `${story.lat}, ${story.lon}`
                      : "Tidak tersedia"
                  }</small>
                  ${dateInfo}
                </div>
              </div>
            </article>
          `;
        })
        .join("");

      container.innerHTML = storyItems;

      // Fit map bounds to show all markers
      if (markers.length > 0 && this._map) {
        const group = new L.featureGroup(markers);
        this._map.fitBounds(group.getBounds().pad(0.1));

        const infoElement = document.createElement("div");
        infoElement.innerHTML = `
          <p style="text-align: center; color: #666; margin: 20px 0 10px 0; font-size: 14px;">
            Menampilkan ${markers.length} dari ${stories.length} cerita yang memiliki lokasi di peta
          </p>
        `;
        container.insertBefore(infoElement, container.firstChild);
      } else if (this._map) {
        const noLocationMessage = document.createElement("div");
        noLocationMessage.innerHTML = `
          <div style="text-align: center; color: #666; margin: 20px 0; padding: 20px; background: #f9f9f9; border-radius: 8px;">
            <p>Tidak ada cerita yang memiliki informasi lokasi spesifik.</p>
            <p>Cerita tetap ditampilkan di bawah, namun tidak memiliki marker di peta.</p>
          </div>
        `;
        container.insertBefore(noLocationMessage, container.firstChild);
      }

      // Add interactivity to story cards
      this._setupStoryInteractivity(markers);
    } catch (error) {
      console.error("Error loading stories:", error);
      if (loadingMessage) loadingMessage.remove();

      container.innerHTML = `
        <div style="text-align: center; padding: 40px; color: #666;">
          <p>Gagal memuat cerita. Silakan coba lagi nanti.</p>
          <button id="retry-stories" style="margin-top: 15px; padding: 10px 20px; background: #1976d2; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Coba Lagi
          </button>
        </div>
      `;

      // Add retry functionality
      const retryButton = document.getElementById("retry-stories");
      if (retryButton) {
        retryButton.addEventListener("click", () => {
          this._loadStories();
        });
      }
    }
  },

  _setupStoryInteractivity(markers) {
    const container = document.querySelector("#story-list");

    container.querySelectorAll(".story-card").forEach((card) => {
      const hasCoordinates =
        card.getAttribute("data-has-coordinates") === "true";
      const index = parseInt(card.getAttribute("data-index"), 10);

      if (hasCoordinates && markers[index] && this._map) {
        // Click interaction
        card.addEventListener("click", () => {
          markers[index].openPopup();
          this._map.setView(markers[index].getLatLng(), 12);

          // Add visual feedback
          card.style.transform = "scale(0.98)";
          setTimeout(() => {
            card.style.transform = "scale(1)";
          }, 150);
        });

        // Keyboard interaction
        card.addEventListener("keypress", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            markers[index].openPopup();
            this._map.setView(markers[index].getLatLng(), 12);
          }
        });

        // Hover effects
        card.addEventListener("mouseenter", () => {
          card.style.cursor = "pointer";
          card.style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)";
        });

        card.addEventListener("mouseleave", () => {
          card.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
        });
      } else {
        card.style.cursor = "default";
        card.removeAttribute("tabindex");
      }
    });
  },

  // Cleanup method untuk menghindari memory leaks
  cleanup() {
    if (this._map) {
      this._map.remove();
      this._map = null;
    }
  },
};

export default HomePage;
