class AuthService {
  constructor() {
    this.tokenKey = "authToken";
    this.userKey = "userData";
  }

  // Simpan data login
  login(token, userData) {
    localStorage.setItem(this.tokenKey, token);
    localStorage.setItem(this.userKey, JSON.stringify(userData));
  }

  // Logout
  logout() {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  }

  // Cek apakah user sudah login
  isLoggedIn() {
    return !!this.getToken();
  }

  // Ambil token
  getToken() {
    return localStorage.getItem(this.tokenKey);
  }

  // Ambil data user
  getUser() {
    const userData = localStorage.getItem(this.userKey);
    return userData ? JSON.parse(userData) : null;
  }

  // Ambil nama user
  getUserName() {
    const user = this.getUser();
    return user ? user.name : "Pengguna";
  }
}

export const authService = new AuthService();
